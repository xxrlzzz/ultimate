# BPMNgenerator

#### 介绍
状态图生成器，可接收需求规约，输出状态图。项目主函数入口为SMGenMainClass。