package main.kotlin.bpmn

data class BPMNElementDescriptor(val name: String, val type: String, val id: String)